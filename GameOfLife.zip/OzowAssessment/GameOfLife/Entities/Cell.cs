﻿using System;
using System.Collections.Generic;
using System.Text;
using GameOfLife.Enums;

namespace GameOfLife.Entities
{
    public class Cell
    {
        public State State { get; set; }
       
    }
}
