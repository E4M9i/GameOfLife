Hi dear Ozow assesor,

Please note you can change settings of Game of Life by simply edit values in setting.json.
If you keep debug mode True it will create series of files in order to trace generations.
Log folder path can be changed as you wish.
Symbols of dead and alive also can be edited which is kind of fun to see the game in diffrent look, it's actually was my son's idea:)

Looking forward to hear your feedback.

Sincerly,
Ehsan