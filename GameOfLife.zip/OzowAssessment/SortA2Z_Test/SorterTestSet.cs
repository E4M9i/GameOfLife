using System;
using System.Linq;
using SortA2Z;
using Xunit;

namespace SortA2Z_Test
{
    public class SorterTestSet
    {
        private readonly Sorter _sorter;

        public SorterTestSet()
        { 
            // arrange
            _sorter =  new Sorter(); 
        }

        [Theory]
        //we can add test cases over refactoring phase with minimum effort by using Theory and inline data.<Ehsan>
        [InlineData("Contrary to popular belief, the pink unicorn flies east.", "Contrarytopopularbeliefthepinkunicornflieseast")]
        [InlineData("c@l##e./4'!?\'><|}A{$%^&*()~`+=-n", "cleAn")]
        [InlineData("c@l##e./4'!?\'><|}a{$%^&*()~`+=-n", "clean")]
        [InlineData("00c1l23e4a567n98", "clean")] 
        public void CleanInputTest(string input,string expectedCleanInput)
        {
            // act
            var cleanInput = _sorter.CleanInput(input);

            // assert
            Assert.Equal(expectedCleanInput, cleanInput);

        }
       [Theory]
       //we can add test cases over refactoring phase with minimum effort by using Theory and inline data.<Ehsan>
        [InlineData("qweryuiopasdfghjklzxcvbnmMNBVCXZLKJHGFDSAPOIUYTREWQ", "aabbccddeeffgghhiijjkkllmmnnooppqqrrsstuuvvwwxxyyzz")]
       [InlineData("Contrarytopopularbeliefthepinkunicornflieseast", "aaabcceeeeeffhiiiiklllnnnnooooppprrrrssttttuuy")]

        public void SortTest(string input,string expectedResult)
        {
            // act
             var result = _sorter.Sort(input);

            // assert
            Assert.Equal(expectedResult,result);
        }

    }
}
