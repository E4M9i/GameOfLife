﻿using System.Text.RegularExpressions;

namespace SortA2Z
{
    public class Sorter
    {
       
        public string CleanInput(string input)
        {
            return Regex.Replace(input, @"[^a-z]", "", RegexOptions.IgnoreCase);

        }

        public string Sort(string cleanInput)
        {
            var arr = new string[32];
            var result = string.Empty;

            foreach (var c in cleanInput.ToLower())
            {
                var index = c-97;
                arr[index] = arr[index] + c;
            }
            for (var i = 0; i < 32; i++)
            {
                result += arr[i];
            }

            return result;
        }
    }
}