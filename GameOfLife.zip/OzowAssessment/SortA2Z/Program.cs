﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace SortA2Z
{
    class Program
    {
        static void Main(string[] args)
        {
            var sorter = new Sorter();

            do
            {
                Console.WriteLine("Input your text to be sorted:");
                var input = Console.ReadLine();
                var cleanTxt = sorter.CleanInput(input);
                var result = sorter.Sort(cleanTxt);
                Console.WriteLine(result);
                Console.WriteLine("Would you like to continue:[Yes: any key]/[No: Esc]");
            } while (Console.ReadKey(true).Key != ConsoleKey.Escape);
        }
    }
}
